CREATE TABLE "hashtags" (
    "id" SERIAL PRIMARY KEY,
    "name" VARCHAR(30) NOT NULL,
    "created_at" TIMESTAMP DEFAULT NOW()
);
