INSERT INTO "users" ("username", "email", "password", "profile_img_url") VALUES
  ('AllanaMoreira'  , 'allanamoreira@driven.com'   , 'senhaallana'  , 'https://comoequetala.com.br/images/com_vagasejobs/usuarios/foto/xdefault.jpg.pagespeed.ic.CGFVrlSKtr.jpg'),
  ('BenícioFreire'  , 'beníciofreire@driven.com'   , 'senhabenicio' , 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT58jJnNRsrHzqkLZPXhf-eEg0Q-W8Qx4MjTQ&usqp=CAU'),
  ('OrlandoPequeno' , 'orlandopequeno@driven.com'  , 'senhaorlando' , 'https://c3.disneyguia.com.br/site/wp-content/uploads/2016/12/24191937/PEQUENO-cinderella-castle-gallery14.jpg'),
  ('OlgaCascais'    , 'olgacascais@driven.com'     , 'senhaolga'    , 'https://images-na.ssl-images-amazon.com/images/I/41b7snNTSoL._SX388_BO1,204,203,200_.jpg'),
  ('MartinhaLima'   , 'martinhalima@drive.com'     , 'senhamartinha', 'https://resizedimgs.zapimoveis.com.br/crop/420x236/named.images.sp/b2a510f6a1bfc4d950e6c2cccd1d0db1/loja-salao-ponto-comercial-para-alugar-260m-no-santa-martinha-ribeirao-das-neves.jpg' ),
  ('AnabelaBaptista', 'anabelabaptista@driven.com' , 'senhaana'     , 'https://images.tcdn.com.br/img/img_prod/822778/sandalia_anabela_barbante_preto_santa_lolla_457_1_1792a39903791f198f552890e7f01cfa.jpg'),
  ('RaulArouca'     , 'raularouca@driven.com'      , 'senharaul'    , 'https://pbs.twimg.com/profile_images/1367103390220713986/BGpaSOpR_400x400.jpg'),
  ('ChicoBuarque'   ,  'chicobuarque@driven.com'   , 'senhachico'   , 'https://i0.wp.com/farofafa.com.br/wp-content/uploads/2022/06/01125658940174.jpg.webp?fit=960%2C640&ssl=1'),
  ('LuccaSantarém'  , 'luccasantarem@driven.com'   , 'senhalucca'   , 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSg_Zh7GGCXc-yHB8nYCDKnyAuUWcStQKRz-Ghqz8uBtafqnT0BqSHnv-EdkYHACfZ3pq8&usqp=CAU'),
  ('PatríciaToste'  ,   'patrciatoste@driven.com'  , 'senhapatrica' , 'https://mir-s3-cdn-cf.behance.net/projects/404/14506949.54859ba47f5ea.jpg');
