CREATE TABLE "post_hashtags" (
    "id" SERIAL PRIMARY KEY,
    "post_id" INTEGER NOT NULL REFERENCES postS(id),
    "hashtag_id" INTEGER NOT NULL REFERENCES hashtags(id)
);
