INSERT INTO "post_hashtags" ("post_id", "hashtag_id") VALUES
  (3, 1),
  (3, 2),
  (6, 3),
  (7, 4);
