CREATE TABLE "sessions" (
    "id" SERIAL PRIMARY KEY,
    "user_id" INTEGER NOT NULL REFERENCES users(id),
    "token" TEXT NOT NULL UNIQUE,
    "created_at" TIMESTAMP DEFAULT NOW()
);
