INSERT INTO "post_likes" ("user_id", "post_id") VALUES
  (4, 1),
  (1, 2),
  (3, 2),
  (4, 2),
  (5, 3),
  (6, 9),
  (7, 9),
  (8, 1),
  (8, 4);
