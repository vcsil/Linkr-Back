INSERT INTO "sessions" ("user_id", "token") VALUES
  (1, '773f4e38-b9c1-42c9-b9d6-3dac3c851ab3'),
  (8, '5703a37c-0a9f-42ca-8d19-f21343511adc');
