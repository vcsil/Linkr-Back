INSERT INTO "sessions" ("user_id", "token") VALUES
  (1, 'alanatoken'),
  (8, 'chicotoken');
