INSERT INTO "posts" ("user_id", "text", "url") VALUES
  (1, 'first'                 , 'https://www.google.com.br'),
  (2, 'dntk'                  , ''),
  (2, 'orkut #BomABessa #Beça', 'https://www.github.com'),
  (3, 'caderno'               , 'https://www.notion.so'),
  (5, 'som'                   , 'https://www.spotify.com'),
  (6, 'video #Audiovisual'    , 'https://www.youtube.com'),
  (7, 'msn #Chat'             , ''),
  (8, 'acabando'              , 'https://www.globo.com.br'),
  (8, 'outlook'               , 'https://www.gmail.com'),
  (4, 'sanidade'              , 'https://www.twitter.com');
