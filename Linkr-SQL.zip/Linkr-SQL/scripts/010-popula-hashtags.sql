INSERT INTO "hashtags" ("name") VALUES
  ('BomABessa'),
  ('Beça'),
  ('Audiovisual'),
  ('Chat');
