CREATE TABLE "users" (
    "id" SERIAL PRIMARY KEY,
    "username" VARCHAR(40) NOT NULL,
    "email" TEXT NOT NULL UNIQUE,
    "password" VARCHAR(40) NOT NULL,
    "profile_img_url" TEXT NOT NULL,
    "created_at" TIMESTAMP DEFAULT NOW()
);

