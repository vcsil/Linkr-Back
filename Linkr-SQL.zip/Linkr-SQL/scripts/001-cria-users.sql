CREATE TABLE "users" (
    "id" SERIAL PRIMARY KEY,
    "username" VARCHAR(40) NOT NULL,
    "email" TEXT NOT NULL UNIQUE,
    "password" TEXT NOT NULL,
    "profile_img_url" TEXT NOT NULL,
    "created_at" TIMESTAMP DEFAULT NOW()
);

